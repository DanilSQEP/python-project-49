### Hexlet tests and linter status:
[![Actions Status](https://github.com/DanilSQEP/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/DanilSQEP/python-project-49/actions)

<a href="https://codeclimate.com/github/DanilSQEP/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/78d6f2501e335359e7ff/maintainability" /></a>

#brain-even
https://asciinema.org/a/v7ZsleecriHMItZGK7xC86FMA

#brain-calc
https://asciinema.org/a/iBv6dpRYx4ixiD8RjfMUx5BeD

#brain-gcd
https://asciinema.org/a/9rvRuRJ2mmlXhItSPhjNe3cVX
