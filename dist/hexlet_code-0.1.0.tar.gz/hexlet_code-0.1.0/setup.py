# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/DanilSQEP/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/DanilSQEP/python-project-49/actions)\n\n<a href="https://codeclimate.com/github/DanilSQEP/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/78d6f2501e335359e7ff/maintainability" /></a>\n\n#brain-even\nhttps://asciinema.org/a/v7ZsleecriHMItZGK7xC86FMA\n\n#brain-calc\nhttps://asciinema.org/a/iBv6dpRYx4ixiD8RjfMUx5BeD\n\n#brain-gcd\nhttps://asciinema.org/a/9rvRuRJ2mmlXhItSPhjNe3cVX\n\n#brain-progression\nhttps://asciinema.org/a/12gjzDJuvfJ6Z7GbaJ6LQbpzH\n',
    'author': 'Daniil',
    'author_email': 'sir.daniil0202@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
